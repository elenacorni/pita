rm tmp_*
rm file_output_da_mod_column.txt
rm core.*
rm *_ext_utr.stab
